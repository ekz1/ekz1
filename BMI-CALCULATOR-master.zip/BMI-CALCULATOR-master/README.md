# BMI-CaLCULATOR
Body mass index (BMI) is a measure of body fat based on height and weight that applies to adult men and women.
Select your gender, Enter your weight and height .
and calculate you BMI
